"""
A command line tool that will take any json input and output a flat csv file.
"""

import json
import csv
import os


def write(parsed_json):
    fieldnames = []

    for x in parsed_json:
        for _ in parsed_json[x]:
            a = 0
            while a + 1 < len(parsed_json[x]):
                for y in parsed_json[x][a]:
                    # print(y, parsed_json[x][a][y])
                    if y not in fieldnames:
                        fieldnames.append(y)
                a += 1

    with open('output.csv', 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for x in parsed_json:
            for _ in parsed_json[x]:
                a = 0
                while a + 1 < len(parsed_json[x]):
                    writer.writerow(parsed_json[x][a])
                    a += 1


def parse():
    for file in os.listdir('./input/'):
        print(file)
        file = f'./input/{file}'
        with open(file, 'r', encoding='utf-8') as f:
            parsed_json = json.load(f)

    return parsed_json


if __name__ == '__main__':
    write(parse())